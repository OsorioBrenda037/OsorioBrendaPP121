
package primerparcial121;

public class Ilustracion extends Publicacion {
    private String ilustrador;
    private double alto;
    private double ancho;

    public Ilustracion(String ilustrador, double alto, double ancho, String titulo, int anioPublicacion) {
        super(titulo, anioPublicacion);
        this.ilustrador = ilustrador;
        this.alto = alto;
        this.ancho = ancho;
    }

    @Override
    public String toString() {
        return "Ilustracion[" + "Ilustrador: " + ilustrador + ", alto: " + alto + ", ancho: " + ancho + ']';
    }
    
    
}
