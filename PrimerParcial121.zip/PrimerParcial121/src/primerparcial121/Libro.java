
package primerparcial121;

public class Libro extends Publicacion {
    private String autor;
    private Genero genero;

    public Libro(String autor, Genero genero, String titulo, int anioPublicacion) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Libro[" + "Autor: " + autor + ", genero: " + genero + ']';
    }

}
