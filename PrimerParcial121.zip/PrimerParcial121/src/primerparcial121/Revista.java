
package primerparcial121;

public class Revista extends Publicacion {
    private int nroEdicion;

    public Revista(int nroEdicion, String titulo, int anioPublicacion) {
        super(titulo, anioPublicacion);
        this.nroEdicion = nroEdicion;
    }

    @Override
    public String toString() {
        return "Revista[" + "NroEdicion: " + nroEdicion + ']';
    }
    
    
    
}
