
package primerparcial121;

public class PublicacionYaExisteException extends RuntimeException{
    private static final String MENSAJE = "Esta publicacion ya esta en la biblioteca.";

    public PublicacionYaExisteException() {
        super(MENSAJE);
    }
    
    
}
