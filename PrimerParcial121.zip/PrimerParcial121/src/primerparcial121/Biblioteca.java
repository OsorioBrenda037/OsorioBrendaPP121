
package primerparcial121;

import java.util.ArrayList;
import java.util.Objects;

public class Biblioteca {
    public ArrayList<Publicacion> listaPublicaciones;
    
    public Biblioteca() {
        listaPublicaciones = new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicacion p) {
        if (listaPublicaciones.contains(p)) {
            throw new PublicacionYaExisteException();
        }
        listaPublicaciones.add(p);
    }

    
    public void mostrarPublicacion() {
        for (Publicacion p: listaPublicaciones) {
            System.out.println(p);
        }
    }
    
    public void leerPublicaciones() {
        for (Publicacion p: listaPublicaciones) {
            if (p instanceof Libro || p instanceof Revista) {
                System.out.println("Leyendo " + p.getTitulo());
            }
            else {
                System.out.println("La ilustracion no se puede leer.");
            }
        }

    }

}
