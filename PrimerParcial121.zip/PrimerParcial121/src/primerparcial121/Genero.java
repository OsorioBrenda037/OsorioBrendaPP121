
package primerparcial121;

public enum Genero {
    FICCION,
    NO_FICCION,
    HISTORIA,
    CIENCIA
}
