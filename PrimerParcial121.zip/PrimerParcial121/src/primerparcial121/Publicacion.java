
package primerparcial121;

import java.util.Objects;

public abstract class Publicacion {
    private String titulo;
    private int anioPublicacion;

    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }
    
    @Override
    public String toString() {
        return "Publicacion: \n" + 
               "titulo: " + titulo + "\n" +
               "anioPublicacion: " + anioPublicacion + "\n";
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Publicacion other = (Publicacion) obj;
        return this.titulo.equals(other.titulo) && this.anioPublicacion == other.anioPublicacion;
    }
    
    
    
}
