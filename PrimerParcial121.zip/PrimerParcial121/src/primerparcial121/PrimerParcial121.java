
package primerparcial121;

public class PrimerParcial121 {

    public static void main(String[] args) {
        
        Biblioteca biblioteca = new Biblioteca();
        
        try {
            //Agrego publicaciones
            biblioteca.agregarPublicacion(new Libro("H. G. Wells", Genero.FICCION, "La Guerra de los Mundos", 1898));
            biblioteca.agregarPublicacion(new Revista(436, "Muy Interesante", 2024));
            biblioteca.agregarPublicacion(new Ilustracion("Daniel Osorio", 125.5, 105.0, "La naranja pensante", 2015));
            biblioteca.agregarPublicacion(new Libro("Rodolfo Walsh", Genero.NO_FICCION, "Operacion Masacre", 1957));
            biblioteca.agregarPublicacion(new Revista(875, "Caras", 2010));
            biblioteca.agregarPublicacion(new Ilustracion("Quiros Camila", 50, 100,"El lavaropas", 2021));
            
            System.out.println();
            
            biblioteca.mostrarPublicacion();
            
            System.out.println();
            biblioteca.leerPublicaciones();
            
            System.out.println();
            
            //Repetidos
            biblioteca.agregarPublicacion(new Libro("H. G. Wells", Genero.FICCION, "La Guerra de los Mundos", 1898));
            biblioteca.agregarPublicacion(new Revista(875, "Caras", 2010));
            biblioteca.agregarPublicacion(new Ilustracion("Quiros Camila", 50, 100,"El lavaropas", 2021));
            
            System.out.println();
            
            biblioteca.mostrarPublicacion();
            
            System.out.println();
            
            biblioteca.leerPublicaciones();
            
            System.out.println();
        } catch(PublicacionYaExisteException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
